<?php
include("options.php");

$title = "LADXR: Legend Of Zelda: Links Awakening RANDOMIZER, v??";
$action = "generate.php";
include("main.template.php");
?>