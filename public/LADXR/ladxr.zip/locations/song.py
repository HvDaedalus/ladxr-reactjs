from .droppedKey import DroppedKey


class Song(DroppedKey):
    pass
